#!/usr/bin/env python3
import sys
import uvicorn
from pathlib import Path

# Add project root to sys.path
root_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root_dir))

def main():
    print("=================================================================")
    print("   Starting AI-Based Medical Image Diagnosis System")
    print("   PACS Triage & Multi-Modal Clinical Intelligence Platform")
    print("=================================================================")
    print("Web UI Cockpit: http://localhost:8000/")
    print("API Swagger Docs: http://localhost:8000/docs")
    print("-----------------------------------------------------------------")
    uvicorn.run("backend.app.main:app", host="0.0.0.0", port=8000, reload=False)

if __name__ == "__main__":
    main()
